# Example 1

This is an example of using CloudWatch Events to invoke a Lambda Function to monitor the total time and success rate
of connecting to a URL.
